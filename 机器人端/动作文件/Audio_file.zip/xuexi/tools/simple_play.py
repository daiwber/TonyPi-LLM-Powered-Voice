from pydub import AudioSegment
from pydub.playback import play
import os


def play_mp3():
    file_dir = os.path.dirname(os.path.abspath(__file__))
    file_name = "edge-tts-output.mp3"
    file_path = os.path.join(file_dir, "Audio_file", file_name)

    audio = AudioSegment.from_file(file_path, format="mp3")
    play(audio)
