import random
import time
from threading import Thread
from paho.mqtt.client import Client


def on_message(client, userdata, msg):
    print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Failed to connect, return code %d\n", rc)


class SimpleMQTTClient(Thread):
    def __init__(self, topic):
        super().__init__()
        self.broker = '101.43.151.85'
        self.port = 1883
        self.topic = topic
        self.client_id = f'python-mqtt-{random.randint(0, 100)}'
        self.client = Client()
        self.client.on_connect = on_connect
        self.client.on_message = on_message
        self.client.connect(self.broker, self.port, 60)
        self.client.subscribe(self.topic)

    def run(self):
        self.client.loop_forever()


if __name__ == '__main__':
    client = SimpleMQTTClient('test_pub')
    client.start()
    client.join()
    while True:
        time.sleep(2)
        print(" ")