import os
import edge_tts
import asyncio


# 速度
rate = '+10%'
# 音量
volume = '+20%'
# 中文音色
voice_list = [
    {"Name": "zh-CN-XiaoxiaoNeural", "Gender": "Female"},
    # {"Name": "zh-CN-XiaoyiNeural", "Gender": "Female"},
]
file_dir = os.path.dirname(os.path.abspath(__file__))
file_name = "edge-tts-output.mp3"
filepath = file_dir + "/Audio_file/" + file_name


async def my_function(text, voice, output):
    tts = edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume)
    await tts.save(output)


def edge_TTS(text):
    voice_name = voice_list[0]["Name"]
    # 创建文件
    if not os.path.exists(filepath):
        with open(filepath, 'w') as f:
            pass
    asyncio.run(my_function(text, voice_name, filepath))


if __name__ == "__main__":
    print("hello world!")
    edge_TTS("你好啊")
