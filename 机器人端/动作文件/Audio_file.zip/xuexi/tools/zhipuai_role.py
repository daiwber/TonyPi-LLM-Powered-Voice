def Human_Message(content):
    return {"role": "user", "content": content}


def AI_Message(content):
    return {"role": "assistant", "content": content}


def System_Message(content):
    return {"role": "system", "content": content}


def combine_message(msg, role_msg):
    if msg is None:
        message = []
    else:
        message = msg
    message.append(role_msg)
    return
