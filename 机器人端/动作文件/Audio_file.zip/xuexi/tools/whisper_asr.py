import whisper
import os


def Speech2text():
    model = whisper.load_model("base", device="cpu")
    file_dir = os.path.dirname(os.path.abspath(__file__))
    file_name = "record.wav"
    file_path = os.path.join(file_dir, "Audio_file", file_name)
    audio = whisper.load_audio(file_path)
    result = model.transcribe(audio, fp16=False)
    print(result["text"])
    return result["text"]


if __name__ == '__main__':
    Speech2text()
