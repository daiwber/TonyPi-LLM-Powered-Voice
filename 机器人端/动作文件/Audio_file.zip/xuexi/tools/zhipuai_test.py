from zhipuai import ZhipuAI


client = ZhipuAI(api_key=zhipuai_key)


def chatZhipuai(msg):
    response = client.chat.completions.create(
        model="glm-4",  # 填写需要调用的模型名称
        messages=msg
    )
    return response.choices[0].message.content


# def creat_history(history, query):
#     if history == "":
#         return [{"role": "user", "content": f"{query}"}]
#     messages = []
#     lines = history.splitlines()
#     for i in lines:
#         role = i.split(":")[0]
#         content = i.split(":")[1:]
#         content = ":".join(content)
#         if role == "我":
#             role = "user"
#         elif role == "AI":
#             role = "assistant"
#         else:
#             continue
#         conbine = {"role": role, "content": content}
#         messages.append(conbine)
#     new_content = {"role": "user", "content": f"{query}"}
#     messages.append(new_content)
#     return messages


if __name__ == '__main__':
    res = chatZhipuai("你好")
    print(res)
