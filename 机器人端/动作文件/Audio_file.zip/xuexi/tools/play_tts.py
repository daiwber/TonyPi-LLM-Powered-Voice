import os
from threading import Thread
import time
import wave
import pyaudio
from pydub import AudioSegment
import simpleaudio as sa


class Play_TTS(Thread):
    def __init__(self):
        super().__init__()
        self.play_obj = None
        file_dir = os.path.dirname(os.path.abspath(__file__))
        edge_file_name = "edge-tts-output.mp3"
        wav_file_name = "final.wav"
        self.filepath = file_dir+"/Audio_file/"+edge_file_name
        self.wav_filename =  file_dir+"/Audio_file/"+wav_file_name

    def trans_mp3_to_wav(self):
        song = AudioSegment.from_mp3(self.filepath)

        if not os.path.exists(self.wav_filename):
            with open(self.wav_filename, 'w') as f:
                pass
        song.export(self.wav_filename, format="wav")

    def play_mp3(self):
        self.trans_mp3_to_wav()
        wave_obj = sa.WaveObject.from_wave_file(self.wav_filename)
        self.play_obj = wave_obj.play()

    def run(self):
        self.trans_mp3_to_wav()
        wave_obj = sa.WaveObject.from_wave_file(self.wav_filename)
        self.play_obj = wave_obj.play()

    def get_play_obj(self):
        return self.play_obj

def play():
    file_dir = os.path.dirname(os.path.abspath(__file__))
    edge_file_name = "edge-tts-output.mp3"
    wav_file_name = "final.wav"
    filepath = file_dir+"/Audio_file/"+edge_file_name
    wav_filename =  file_dir+"/Audio_file/"+wav_file_name

    song = AudioSegment.from_mp3(filepath)

    if not os.path.exists(wav_filename):
        with open(wav_filename, 'w') as f:
            pass
    song.export(wav_filename, format="wav")
    
    audio = pyaudio.PyAudio()  # 新建一个PyAudio对象
    # wave.open跟python内置的open有点类似，从wf中可以获取音频基本信息
    with wave.open("./final.wav", "rb") as wf:
            stream = audio.open(format=pyaudio.paInt16,  # 指定数据类型是int16，也就是一个数据点占2个字节；paInt16=8，paInt32=2，不明其含义，先不管
                            channels=wf.getnchannels(),  # 声道数，1或2
                            rate=wf.getframerate(),  # 采样率，44100或16000居多
                            frames_per_buffer=1024,  # 每个块包含多少帧，详见下文解释
                            output=True)  # 表示这是一个输出流，要对外播放的
            # getnframes获取整个文件的帧数，readframes读取n帧，两者结合就是读取整个文件所有帧
            stream.write(wf.readframes(wf.getnframes()))  # 把数据写进流对象
            stream.stop_stream()  # stop后在start_stream()之前不可再read或write
            stream.close()  # 关闭这个流对象
    audio.terminate()  # 关闭PyAudio对象


if __name__ == "__main__":
    player = Play_TTS()
    player.start()
    player.join()
    # 多线程使用的话必须保持主线程存活,不然播放线程会在主线程停止时停止
    # 这里使用while循环来保持主线程的存活
    while True:
        time.sleep(0.01)
    # 需要提前终止播放线程就使用下面的代码 
    
    # play_obj = player.get_play_obj()
    # play_obj.stop()
