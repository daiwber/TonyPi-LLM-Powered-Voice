
import pyaudio
import wave
from aip import AipSpeech
import socket
import subprocess
import threading
import json
import websocket
import _thread as thread
import time
import base64
import hashlib
import hmac
from urllib.parse import urlparse
import ssl
from datetime import datetime
from time import mktime
from urllib.parse import urlencode
from wsgiref.handlers import format_date_time
import openpyxl
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import pygame.mixer

# 百度语音识别相关
APP_ID = '57837401'
API_KEY = 'VoYaoqbnT66vJkuqZbModmQA'
SECRET_KEY = 'hgKJW1xSHyydyQfosscSCe4QXqjGSbVm'
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
RATE = 16000
CHUNK_SIZE = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RECORD_SECONDS = 5
class Ws_Param(object):
    # 初始化
    def __init__(self, APPID, APIKey, APISecret, gpt_url):
        self.APPID = APPID
        self.APIKey = APIKey
        self.APISecret = APISecret
        self.host = urlparse(gpt_url).netloc
        self.path = urlparse(gpt_url).path
        self.gpt_url = gpt_url
    # 生成url
    def create_url(self):
        # 生成RFC1123格式的时间戳
        now = datetime.now()
        date = format_date_time(mktime(now.timetuple()))
        # 拼接字符串
        signature_origin = "host: " + self.host + "\n"
        signature_origin += "date: " + date + "\n"
        signature_origin += "GET " + self.path + " HTTP/1.1"
        # 进行hmac-sha256进行加密
        signature_sha = hmac.new(self.APISecret.encode('utf-8'), signature_origin.encode('utf-8'),
                                 digestmod=hashlib.sha256).digest()
        signature_sha_base64 = base64.b64encode(signature_sha).decode(encoding='utf-8')
        authorization_origin = f'api_key="{self.APIKey}", algorithm="hmac-sha256", headers="host date request-line", signature="{signature_sha_base64}"'

        authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode(encoding='utf-8')
        # 将请求的鉴权参数组合为字典
        v = {
            "authorization": authorization,
            "date": date,
            "host": self.host
        }
        # 拼接鉴权参数，生成url
        url = self.gpt_url + '?' + urlencode(v)
        # 此处打印出建立连接时候的url,参考本demo的时候可取消上方打印的注释，比对相同参数时生成的url与自己代码生成的url是否一致
        return url
def convert_to_wav(input_file_path, output_wav_path):
    # 使用ffmpeg命令将任意格式音频转换为wav格式
    command = f'ffmpeg -i "{input_file_path}" -vn -acodec pcm_s16le -ar 16000 -ac 1 "{output_wav_path}"'
    
    # 执行ffmpeg命令
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to convert the file using ffmpeg: {e}")
        return False
    return True
def record_and_recognize(input_format=None):
    p = pyaudio.PyAudio()
    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK_SIZE)
    frames = []
    for i in range(0, int(RATE / CHUNK_SIZE * RECORD_SECONDS)):
        data = stream.read(CHUNK_SIZE)
        frames.append(data)
    audio_data = b''.join(frames)
    stream.stop_stream()
    stream.close()
    p.terminate()
    result = client.asr(audio_data, 'pcm', RATE, {'dev_pid': 1537})
    return result['result'][0]
def handle_voice_input(wsParam, domain):
    with open('gpt_answers.txt', 'w') as f:
        f.truncate(0)
    voice_query = record_and_recognize()
    ws = websocket.WebSocketApp(wsParam.create_url(),
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close,
                                on_open=on_open)
    ws.appid = wsParam.APPID
    ws.query = voice_query
    ws.domain = domain
    ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
# ... （原有的on_message, on_error, on_close, on_open方法保持不变）
def on_error(ws, error):
    print("### error:", error)
# 收到websocket关闭的处理
def on_close(ws):
    print("### closed ###")
def on_open(ws):
    thread.start_new_thread(run, (ws,))


def ensure_audio_file_clean(audio_file):
    if os.path.exists(audio_file):
        os.remove(audio_file)
ensure_audio_file_clean('answer_output.wav')
# 添加播放音频函数


def play_audio(file_name):
    try:
        pygame.mixer.init()
        sound = pygame.mixer.Sound(file_name)
        channel = pygame.mixer.Channel(0)
        channel.play(sound)
        while channel.get_busy():  # 等待播放完成
            pygame.time.Clock().tick(10)  # 防止CPU占用过高
        pygame.mixer.quit()  # 结束播放后释放资源
    except pygame.error as e:
        print(f"播放音频文件时发生错误: {e}")
        print("请检查音频文件是否存在以及pygame模块是否正确安装和初始化")

def run(ws, *args):
    # 确保ws.query和ws.domain在调用此函数前已被正确设置
    data = json.dumps(gen_params(appid=ws.appid, query=ws.query, domain=ws.domain))
    ws.send(data)
def gen_params(appid, query, domain):
    # 更新数据结构以满足服务器要求
    data = {
        "header": {
            "app_id": appid,
            # 假设此处需要一个唯一的用户标识符，如果没有则需删除或填充真实UID
        },
        "parameter": {
            "chat": {
                "domain": domain,  # 移动 domain 到 parameter.chat 内
                "temperature": 0.5,
                "max_tokens": 1024,
            }
        },
        "payload": {
            "message": {
                "text": [
                    {"role": "user", "content": query}  # 最新的一条问题，这里是语音识别结果
                ]
            }
        }
    }
    # 如果不需要对话背景设置，可以去掉第一个元素；如果已经有历史对话，把它们加上去即可
    return data
    # 根据实际情况补充 header 和 parameter 字段的内容
    return data
# 百度语音合成相关
TTS_APP_ID = '58410654'
TTS_API_KEY = 'ganEmJkl7DqNgIqcDFc2IfZu'
TTS_SECRET_KEY = 'jxlffiayHbPRrECwzWZ25mDvPXckQZFu'
tts_client = AipSpeech(TTS_APP_ID, TTS_API_KEY, TTS_SECRET_KEY)

generated_audio_files = []

def on_message(ws, message):
    data = json.loads(message)
    try:
        choices = data["payload"]["choices"]
        status = choices["status"]
        content = choices["text"][0]["content"]
        
        print(content, end='')
        with open('gpt_answers.txt', 'w', encoding='utf-8') as f:
            f.write(content + '\n')
        if status == 2:
            closing_text = "#### 会话已关闭"
            audio_file_closing = 'closing_output.wav'
            text_to_speech(closing_text, audio_file=audio_file_closing)
            play_audio(audio_file_closing)
        with open('gpt_answers.txt', 'r', encoding='utf-8') as f:
            answer_content = f.read().strip()
        audio_file = 'answer_output.wav'
        text_to_speech(answer_content, audio_file=audio_file)
        play_audio(audio_file)
        os.remove(audio_file_closing)
        ws.close()
    except KeyError:
        print("无法从JSON响应中提取有效内容")

# 更新text_to_speech函数，使其接收音频文件名作为参数并存储为指定文件
def text_to_speech(text, audio_file='output.wav'):
    result = tts_client.synthesis(text, 'zh', 1, {'vol': 50, 'per': 0})  # 转换成中文语音，默认音量和发音人
    if not isinstance(result, dict):
        if result:
            with open(audio_file, 'wb') as f:
                f.write(result)
            print(f'语音合成成功，已保存至文件: {audio_file}')
            generated_audio_files.append(audio_file)  # 记录生成的音频文件以便后续清理
        else:
            print('语音合成结果为空，无法保存音频文件')
    else:
        error_code = result.get('error_code')
        if error_code is not None:
           print('语音合成失败，错误码:', error_code)
        else:
           print('语音合成结果中没有包含错误码信息，或者没有错误发生。')
def main(appid, api_secret, api_key, gpt_url, domain):
    wsParam = Ws_Param(appid, api_key, api_secret, gpt_url)
    # 启动一个线程处理语音输入并启动WebSocket连接
    voice_thread = threading.Thread(target=handle_voice_input, args=(wsParam, domain))
    voice_thread.start()
def read_answer_from_file():
    try:
        with open('gpt_answers.txt', 'w', encoding='utf-8') as f:
            answer_content = f.read().strip()
        return answer_content
    except IOError as e:
        if 'not readable' in str(e):
            print(f"无法读取 gpt_answers.txt 文件，原因是: {str(e)}")
            return ""
        else:
            raise e
def process_answer_in_gpt_answers_txt():
    answer_text = read_answer_from_file()
    audio_file = 'answer_output.wav'  # 为生成的语音文件设定一个名字
    text_to_speech(answer_text, audio_file=audio_file)
    play_audio(audio_file)  # 确保play_audio函数已实现并可用
    
def has_been_played(answer_content):
    played_contents_file = 'played_answers.txt'
    with open(played_contents_file, 'r+', encoding='utf-8') as f:
        played_contents = set(line.strip() for line in f.readlines())
        if answer_content in played_contents:
            return True
        else:
            played_contents.add(answer_content)
            f.seek(0)  # 回到文件开头
            f.truncate()  # 清空原有内容
            for item in played_contents:
                f.write(item + '\n')
            return False

if __name__ == "__main__":
    read_answer_from_file()
    for audio_file in generated_audio_files:
        try:
            os.remove(audio_file)
        except FileNotFoundError:
            pass 
    generated_audio_files.clear()

    try:
        import pygame
        pygame.init()
        main(
        appid="5fbcc305",
        api_secret="b3962e47e8419a0194d2a0f29f1602d5",
        api_key="da52598cb28ce14dcaa5efdc2971617f",
        gpt_url="wss://spark-api.xf-yun.com/v3.5/chat",
        domain="generalv3.5", 
       )
        # 在所有语音识别和WebSocket通信完成后处理文本文件
        process_answer_in_gpt_answers_txt()
 # 在main函数结束之后，但在程序退出前
     
    # 清理生成的音频文件（如果不再需要的话）
        # 清除gpt_answers.txt的内容
        with open('gpt_answers.txt', 'w') as f:
           f.truncate(0)

    # 清理生成的音频文件（如果不再需要的话）
        for audio_file in generated_audio_files:
            try:
               os.remove(audio_file)
            except FileNotFoundError:
              pass
        generated_audio_files.clear()
    except ImportError:
        print("播放音频需要安装pygame库，请先安装：pip install pygame")

    