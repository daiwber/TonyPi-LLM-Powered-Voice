import simpleaudio as sa

sa.PlayObject()